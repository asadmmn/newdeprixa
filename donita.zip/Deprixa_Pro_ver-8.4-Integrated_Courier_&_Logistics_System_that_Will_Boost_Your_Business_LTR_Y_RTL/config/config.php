<?php
define("CDP_DB_HOST", "localhost");
define("CDP_DB_NAME", "newdeprixa");
define("CDP_DB_USER", "root");
define("CDP_DB_PASS", "");
define('CDP_APP_URL', 'http://localhost/newdeprixa/Deprixa_Pro_ver-8.4-Integrated_Courier_&_Logistics_System_that_Will_Boost_Your_Business_LTR_Y_RTL/');
define('CDP_APP_MODE_DEMO', false);
?>