<?php
define("CDP_DB_HOST", "localhost");
define("CDP_DB_NAME", "xxxxprueba1");
define("CDP_DB_USER", "xxxxprueba2");
define("CDP_DB_PASS", "xxxxxxx");
define('CDP_APP_URL', 'https://example.com/');
define('CDP_APP_MODE_DEMO', false);
?>