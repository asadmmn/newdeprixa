$(function() {
	// Nice Select
	$('select').niceSelect();
})